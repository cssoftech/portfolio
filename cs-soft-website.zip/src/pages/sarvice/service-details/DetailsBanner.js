import React from 'react';

function DetailsBanner(props) {
    return (
        <section className="banner inner-banner">
            <div className="container">
                <div className="banner-content">
                <h2>Services Details</h2>
                </div>
            </div>
        </section>
    );
}

export default DetailsBanner;